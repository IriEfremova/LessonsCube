package com.example.fateball;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Ищем кнопку на интерфейсе
        ImageView imageView = findViewById(R.id.imageView);
        //Связываем кнопку со слушателем кликов по этой кнопке
        //Для этого создаем новый слушатель new View.OnClickListener(), у которого есть метод onClick(View v)
        //Это и есть тот самый метод, который мы раньше с вами писали и привязывали через свойство
        //В данном случае мы это просто делаем немного по другому и через код. В интерфейсе теперь ничего делать уже не нужно.
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Считываем из ресурсов из файла /res/values/strings.xml список WishList с пожеланиями
                String[] wishList = getResources().getStringArray(R.array.WishList);

                //Определяем размер экрана, чтобы ограничить размер тоста
                DisplayMetrics displaymetrics = new DisplayMetrics();
                getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
                int screenWidth = displaymetrics.widthPixels;

                //Генерируем случайное число в диапазоне от 0 до количества пожеланий
                int randValue = (int)(Math.random() * wishList.length);

                //Создаем компонент ImageView и встраиваем в него картинку, соответствующую сгенерированному номеру пожелания
                ImageView toastImage = new ImageView(getApplicationContext());
                //нулевой картинке прибавляем номер пожелания и получаем нужную картинку
                toastImage.setImageResource(R.drawable.image_0 + randValue);

                //Создаем тост с текстом пожелания согласно сгенерированному номеру пожелания
                Toast toast = Toast.makeText(getApplicationContext(), wishList[randValue], Toast.LENGTH_LONG);

                //У тоста получаем доступ к его вьюшке
                LinearLayout container = (LinearLayout) toast.getView();
                //Встраиваем во вьюшку тоста наш компонент ImageView с нужной картинкой
                container.addView(toastImage, 0);

                //Задаем минимальный размер тоста, чтобы он не мог стать меньше, чем этот размер.
                //Фактически это дает нам зафиксировать размер этого тоста
                toast.getView().setMinimumWidth(screenWidth / 4);

                //Располагаем тост по центру экрана
                toast.setGravity(Gravity.CENTER,0,0);

                //Отображаем тост
                toast.show();
            }
        });
    }
}